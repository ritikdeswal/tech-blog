
import os
from flask import Flask, render_template, request, redirect, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView

app = Flask(__name__)
app.config['FLASK_ADMIN_SWATCH'] = 'darkly'
admin = Admin(app, name='Scorpion-Tech', template_mode='bootstrap3')

# admin.add_view(ModelView(User, db.session))
# admin.add_view(ModelView(Post, db.session))

app.debug = True

env = 'dev'

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/designs")
def designs():
    return render_template("designs.html")


@app.route("/projects")
def projects():
    return render_template("projects.html")


@app.route("/privacy")
def privacy():
    return render_template("privacy.html")






if env == 'dev':
    app.run()
else:
    if __name__ == "__main__":
        port = int(os.environ.get("PORT", 5000))
        app.run(host='0.0.0.0', port=port)