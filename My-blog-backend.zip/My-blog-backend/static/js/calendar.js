var month=['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
var blogDates=["19-6-2021","26-6-2021","12-7-2021"]

const d = new Date();
curr_month=d.getMonth();
curr_year=d.getFullYear();
const d2 = new Date(curr_year,curr_month,1);
month_start=d2.getDay();
document.getElementById("year").innerHTML = curr_year;
document.getElementById("month").innerHTML = month[curr_month];


function prev_month() {
 if (curr_month==0){
     curr_month=12;
     curr_year=curr_year-1
 }   
 curr_month=curr_month-1;
 document.getElementById("month").innerHTML = month[curr_month];
 document.getElementById("year").innerHTML = curr_year;
 fetch_day();
}

function next_month() {
     if (curr_month==11){
         curr_month=-1;
         curr_year=curr_year+1;
         
     }   
 curr_month=curr_month+1;
 document.getElementById("month").innerHTML = month[curr_month];
 document.getElementById("year").innerHTML = curr_year;
 fetch_day();
 }

function prev_year(){
    curr_year=curr_year-1;
    document.getElementById("year").innerHTML = curr_year;
    fetch_day();
}
function next_year(){
    curr_year=curr_year+1;
    document.getElementById("year").innerHTML = curr_year;
    fetch_day();
}

function fetch_day() {
 dd=new Date(curr_year,curr_month,1);
   month_start=dd.getDay();
   table=document.getElementById("tbody");
   updateDay();
}

updateDay();

function updateDay() {
 table=document.getElementById("tbody");
 while (table.hasChildNodes()) {
table.removeChild(table.firstChild);
}
tr=document.createElement("tr");
 //    tr.removeChild(td);
    let c=0;
while (c < month_start) {
 td = document.createElement("td");
 td.innerHTML="";
 tr.appendChild(td);
 c=c+1;
 }
 
 //remaining dates in row 1
 count=1;
 while(c<=6) {
     td2 = document.createElement("td");
     mm=curr_month+1;
     td2.setAttribute("id",count+'-'+ mm+"-"+curr_year);
 td2.innerHTML=count;
 tr.appendChild(td2);
     count=count+1;
     c=c+1;
     if (blogDates.includes(td2.id)) {
        td2.setAttribute("class","dateHighlight");
     }
 }
 table.appendChild(tr);

 // remainng dates in all rows
 for (r=2;r<=6;r=r+1) {
     
     tr2 = document.createElement("tr");
     for (c = 0; c <= 6; c = c + 1){
     td3 = document.createElement('td');
     mm=curr_month+1;
     td3.setAttribute("id",count+'-'+ mm+"-"+curr_year);
     td3.innerHTML = count;
     count=count+1;
     dd2=new Date(curr_year,curr_month+1,0).getDate();
     if (count>dd2+1){
         break;
     }
     tr2.appendChild(td3);
         if (blogDates.includes(td3.id)) {
        td3.setAttribute("class","dateHighlight");
     }
     }

     table.appendChild(tr2);
 }
    
    //highlight blogdates
    
}