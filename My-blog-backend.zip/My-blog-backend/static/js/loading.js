function loadmore() {
                for (i=0;i<6;i=i+1) {
                var div=document.getElementById("firstarticle");
                 var cln = div.cloneNode(true); 
                // div.setAttribute("class","articles");
                mid=document.getElementById("mid");
                    btn=document.getElementById("load-btn");
                mid.insertBefore(cln, btn);
                }
            }